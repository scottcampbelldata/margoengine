import{C as e,E as t,T as n,c as r,l as i,r as a,t as o}from"./index-Bd8B_KrP.js";import{_ as s,a as c,b as l,c as u,d,f,g as p,h as m,i as h,l as g,m as _,n as v,o as y,p as b,r as ee,s as te,t as x,u as ne,v as re,y as ie}from"./line-CXjNQjrU-CydOoLm-.js";import{t as S}from"./mesh-DRwnudr8.js";function ae(e,t){if(e.backend===`webgl2`||!e.gpu)throw new i(`unsupported`,`${t} needs WebGPU; see https://margoengine.com/errors#webgpu`)}function oe(e){return e?.view?.viewport}function se(e,t){let n=oe(t);if(!n)return;e.setViewport(n[0],n[1],n[2],n[3],0,1);let r=t.view.scissor??n;e.setScissorRect(r[0],r[1],r[2],r[3])}var ce=(e,t)=>`
struct MargoFog {color:vec4f,params:vec4f,eye:vec4f}
@group(${e}) @binding(${t}) var<uniform> margoFog:MargoFog;
fn fogAmount(p:vec3f)->f32 {
  let d=distance(p,margoFog.eye.xyz);let q=margoFog.params;
  let amount=select(clamp((d-q.x)/max(q.y-q.x,1e-6),0.0,1.0),1.0-exp(-q.z*q.z*d*d),q.z>0.0);
  return amount*exp(-q.w*max(p.y-margoFog.color.w,0.0));
}
`,C=(e,t,n,r)=>{let i=e===void 0?t:e;if(typeof i!=`number`||!Number.isFinite(i)||i<r)throw RangeError(`Fog ${n} is ${String(i)}; pass a finite number${r===0?`, 0 or more`:``}`);return i};function le(e){if(e!==null&&(typeof e!=`object`||Array.isArray(e)))throw TypeError(`Fog must be an object with Fog fields; pass an environment Fog, such an object or null`);return e&&ue(e,[0,0,0],new Float32Array(12)),e}function ue(e,t,n,r=!1){let i=e.enabled??!0;if(typeof i!=`boolean`)throw TypeError(`Fog enabled is ${String(i)}; pass true or false`);let s=C(e.height,0,`height`,-1/0),c=C(e.near,1,`near`,0),l=C(e.far,1e3,`far`,0),u=C(e.density,0,`density`,0),d=C(e.heightFalloff,0,`heightFalloff`,0);if(o(e.color??`#ffffff`,n,0),r)for(let e=0;e<3;e++)n[e]=a(n[e]);n[3]=s,n[4]=c,n[5]=l,n[6]=u,n[7]=d,i||(n.fill(0,0,8),n[4]=n[5]=34028234663852886e22),n[8]=t[0],n[9]=t[1],n[10]=t[2],n[11]=0}var de=`
const FAN:u32=10u;
const BLOCK:u32=36u;
const PI:f32=3.14159265;
struct Frame{viewProj:mat4x4f,viewport:vec4f,extra:vec4f}
struct Style{model:mat4x4f,color:vec4f,a:vec4f,b:vec4f,flags:vec4u,planes:array<vec4f,6>}
@group(0) @binding(0) var<uniform> frame:Frame;
@group(1) @binding(0) var<uniform> style:Style;
@group(1) @binding(1) var<storage,read> points:array<vec4f>;
@group(1) @binding(2) var<storage,read> colors:array<vec4f>;

fn tinted(p:vec4f,bits:u32,fade:f32)->vec4f{
  let m=style.color;var rgb=m.rgb*p.rgb;
  if((bits&128u)!=0u){rgb=p.rgb;}else if((bits&256u)!=0u){rgb=min(m.rgb+p.rgb,vec3f(1.0));}
  return vec4f(rgb,p.a*m.a*fade);
}
${((e,t)=>`
@group(${e}) @binding(${t}) var<storage,read> margoMask:array<u32>;
fn margoMaskPresent()->bool{return margoMask[3]==1u;}
fn margoMaskOn(i:u32)->bool{return ((margoMask[4u+(i>>5u)]>>(i&31u))&1u)!=0u;}
fn margoMaskHidden(on:bool)->bool{return !on&&margoMask[0]==2u;}
fn margoMaskColor(c:vec4f,on:bool)->vec4f{
  let l=max(c.rgb,vec3f(0.0));
  var s=select(1.055*pow(l,vec3f(1.0/2.4))-0.055,l*12.92,l<=vec3f(0.0031308));
  if(on){if(margoMask[0]!=1u){return c;}let h=unpack4x8unorm(margoMask[2]);s=mix(s,h.rgb,h.a);}
  else{s*=bitcast<f32>(margoMask[1]);}
  return vec4f(select(pow((s+0.055)/1.055,vec3f(2.4)),s/12.92,s<=vec3f(0.04045)),c.a);
}
`)(1,7)}
struct Out{
  @builtin(position) clip:vec4f,
  @location(0) color:vec4f,
  @location(1) @interpolate(linear) edge:vec4f,
  @location(2) dist:f32,
  @location(3) world:vec3f,
}
struct Joint{sOut:f32,miter:bool,innerOk:bool,inner:vec2f,outer0:vec2f,outer1:vec2f,n1:vec2f}
struct Corner{off:vec2f,d:f32,atB:bool,valid:bool}

fn near(i:u32)->vec2f{let v=points[style.flags.y+i/2u];return select(v.xy,v.zw,(i&1u)==1u);}
fn project(i:u32)->vec4f{return frame.viewProj*(style.model*vec4f(points[i].xyz,1.0));}
fn nearSide(c:vec4f)->f32{return c.w-c.z;}
fn screen(c:vec4f)->vec2f{return c.xy/c.w*0.5*frame.viewport.xy;}
fn perp(d:vec2f)->vec2f{return vec2f(-d.y,d.x);}
fn halfWidth(c:vec4f)->f32{
  let width=style.a.x;
  if((style.flags.z&16u)!=0u){return 0.5*width*frame.viewport.w/c.w;}
  return 0.5*width*frame.viewport.z;
}
fn joint(d0:vec2f,d1:vec2f,hwG:f32,len0:f32,len1:f32)->Joint{
  var j:Joint;
  let n0=perp(d0);let n1=perp(d1);
  let cr=d0.x*d1.y-d0.y*d1.x;
  j.sOut=select(1.0,-1.0,cr>0.0);
  let sum=n0+n1;let sl=length(sum);
  var m=n0;var L=1e6;
  if(sl>1e-4){m=sum/sl;L=1.0/max(dot(m,n0),1e-6);}
  j.miter=(style.flags.z&3u)==0u&&L<=style.a.y;
  j.innerOk=L<1e5&&hwG*sqrt(max(L*L-1.0,0.0))<=min(len0,len1);
  j.inner=select(vec2f(0.0),m*(-j.sOut*hwG*L),j.innerOk);
  j.outer0=select(n0*(j.sOut*hwG),m*(j.sOut*hwG*L),j.miter);
  j.outer1=select(n1*(j.sOut*hwG),m*(j.sOut*hwG*L),j.miter);
  j.n1=n1;
  return j;
}


fn arc(start:vec2f,sweep:f32,step:u32,hwG:f32)->vec2f{
  let l=length(start);let s=select(vec2f(1.0,0.0),start/l,l>0.0);let a=sweep*f32(step)/f32(FAN);let c=cos(a);let n=sin(a);
  return vec2f(s.x*c-s.y*n,s.x*n+s.y*c)*hwG;
}

fn fanCorner(k:u32,start:vec2f,sweep:f32,hwG:f32,atB:bool)->Corner{
  let t=k/3u;let c=k%3u;
  var r:Corner;r.atB=atB;r.valid=t>=2u;
  if(!r.valid||c==0u){r.off=vec2f(0.0);r.d=0.0;return r;}
  r.off=arc(start,sweep,t-2u+c-1u,hwG);r.d=hwG;return r;
}

@vertex fn vertex(@builtin(vertex_index) vi:u32,@builtin(instance_index) ii:u32)->Out{
  var o:Out;
  o.clip=vec4f(2.0,2.0,0.0,1.0);o.color=vec4f(0.0);o.edge=vec4f(0.0,1.0,0.0,0.0);o.dist=0.0;
  let mode=style.flags.x;let n=style.flags.y;let bits=style.flags.z;
  let join=bits&3u;let cap=(bits>>2u)&3u;
  var ia:u32;var ib:u32;var ip:u32=0u;var inx:u32=0u;var hasPrev=false;var hasNext=false;
  if(mode==0u){ia=2u*ii;ib=ia+1u;}
  else{
    ia=ii;ib=select(ii+1u,(ii+1u)%n,mode==2u&&n>=3u);
    let na=near(ia);
    if(na.y!=f32(ib)&&(na.x>=0.0||na.y>=0.0)){return o;}
    let nb=near(ib).y;
    hasPrev=na.x>=0.0;ip=u32(max(na.x,0.0));hasNext=nb>=0.0;inx=u32(max(nb,0.0));
  }
  let oa=project(ia);let ob=project(ib);
  let fa=nearSide(oa);let fb=nearSide(ob);
  if(fa<0.0&&fb<0.0){return o;}
  var ta=0.0;var tb=1.0;
  if(fa<0.0){ta=fa/(fa-fb);hasPrev=false;}
  if(fb<0.0){tb=fa/(fa-fb);hasNext=false;}
  let ca=mix(oa,ob,ta);let cb=mix(oa,ob,tb);
  let sa=screen(ca);let sb=screen(cb);
  let seg=sb-sa;let len=length(seg);
  let dir=select(vec2f(1.0,0.0),seg/len,len>1e-4);let nrm=perp(dir);
  var dPrev=dir;var lPrev=0.0;var dNext=dir;var lNext=0.0;
  if(hasPrev){var cp=project(ip);let fp=nearSide(cp);if(fp<0.0){cp=mix(cp,ca,fp/(fp-nearSide(ca)));}
    let v=sa-screen(cp);lPrev=length(v);hasPrev=lPrev>1e-4;dPrev=select(dir,v/lPrev,hasPrev);}
  if(hasNext){var cn=project(inx);let fq=nearSide(cn);if(fq<0.0){cn=mix(cn,cb,fq/(fq-nearSide(cb)));}
    let v=screen(cn)-sb;lNext=length(v);hasNext=lNext>1e-4;dNext=select(dir,v/lNext,hasNext);}
  let aa=style.b.z;
  let rawA=halfWidth(ca);let rawB=halfWidth(cb);
  let hwA=max(rawA,0.5);let hwB=max(rawB,0.5);
  let hwGA=hwA+aa;let hwGB=hwB+aa;
  var jA:Joint;var jB:Joint;
  if(hasPrev){jA=joint(dPrev,dir,hwGA,lPrev,len);}
  if(hasNext){jB=joint(dir,dNext,hwGB,len,lNext);}
  var cr:Corner;cr.valid=true;
  if(vi<6u){
    let ends=array<u32,6>(0u,0u,1u,0u,1u,1u);let sides=array<f32,6>(-1.0,1.0,1.0,-1.0,1.0,-1.0);
    cr.atB=ends[vi]==1u;let side=sides[vi];
    let hasJ=select(hasPrev,hasNext,cr.atB);
    if(hasJ){
      var j=jA;if(cr.atB){j=jB;}
      let hwG=select(hwGA,hwGB,cr.atB);
      if(side==j.sOut){cr.off=select(j.outer1,j.outer0,cr.atB);}
      else{cr.off=select(nrm*(side*hwG),j.inner,j.innerOk);}
    }else{
      let hw=select(hwA,hwB,cr.atB);let hwG=hw+aa;
      var ext=0.0;if(cap==2u){ext=hw+aa;}else if(cap==0u){ext=aa;}
      cr.off=nrm*(side*hwG)+dir*select(-ext,ext,cr.atB);
    }
    cr.d=dot(cr.off,nrm);
  }else if(vi<6u+BLOCK){
    let k=vi-6u;cr.atB=true;
    if(hasNext){
      let t=k/3u;let c=k%3u;
      if(t<2u){
        let ln=select(jB.n1,nrm,t==0u);
        let inner=select(ln*(-jB.sOut*hwGB),jB.inner,jB.innerOk);
        let outer=select(jB.outer1,jB.outer0,t==0u);
        if(c==0u){cr.off=inner;}else if(c==1u){cr.off=vec2f(0.0);}else{cr.off=outer;}
        cr.d=dot(cr.off,ln);
      }else if(jB.miter){cr.valid=false;}
      else if(join!=1u){
        cr.valid=t==2u;
        if(c==0u){cr.off=vec2f(0.0);cr.d=0.0;}else{cr.off=select(jB.outer1,jB.outer0,c==1u);cr.d=hwGB;}
      }else{
        let o0=jB.outer0;let o1=jB.outer1;
        cr=fanCorner(k,o0,atan2(o0.x*o1.y-o0.y*o1.x,dot(o0,o1)),hwGB,true);
      }
    }else if(cap==1u){cr=fanCorner(k,nrm,-PI,hwGB,true);}
    else{cr.valid=false;}
  }else{
    let k=vi-6u-BLOCK;cr.atB=false;
    if(!hasPrev&&cap==1u){cr=fanCorner(k,nrm,PI,hwGA,false);}else{cr.valid=false;}
  }
  if(!cr.valid){cr.off=vec2f(0.0);cr.d=0.0;}
  let base=select(ca,cb,cr.atB);
  let p=select(sa,sb,cr.atB)+cr.off;
  o.clip=vec4f(base.xy+cr.off/(0.5*frame.viewport.xy)*base.w,base.z,base.w);
  let capped=cap!=1u;
  let capA=select(0.0,hwA,cap==2u);let capB=select(0.0,hwB,cap==2u);
  let uStart=select(-1e4,dot(p-sa,-dir)-capA,!hasPrev&&capped);
  let uEnd=select(-1e4,dot(p-sb,dir)-capB,!hasNext&&capped);
  let hw=select(hwA,hwB,cr.atB);
  o.edge=vec4f(cr.d,hw,uStart,uEnd);
  var colA=vec4f(1.0);var colB=vec4f(1.0);
  if((bits&64u)!=0u){colA=mix(colors[ia],colors[ib],ta);colB=mix(colors[ia],colors[ib],tb);}
  let raw=select(rawA,rawB,cr.atB);
  let fade=select(1.0,min(1.0,2.0*raw),aa>0.0);
  o.color=tinted(select(colA,colB,cr.atB),bits,fade);

  if(margoMaskPresent()){let on=margoMaskOn(ia)&&margoMaskOn(ib);if(margoMaskHidden(on)){o.clip=vec4f(2.0,2.0,0.0,1.0);return o;}o.color=margoMaskColor(o.color,on);}
  var dA=points[ia].w;var dB=points[ib].w;
  if(mode==2u&&n>=3u&&ib==0u){dB=style.b.y;}
  o.dist=mix(dA,dB,select(ta,tb,cr.atB));

  let wa=style.model*vec4f(points[ia].xyz,1.0);let wb=style.model*vec4f(points[ib].xyz,1.0);
  o.world=mix(wa.xyz/wa.w,wb.xyz/wb.w,select(ta,tb,cr.atB));
  return o;
}

fn encode(c:vec3f)->vec3f{return select(c*12.92,1.055*pow(c,vec3f(1.0/2.4))-0.055,c>=vec3f(0.0031308));}

@fragment fn fragment(i:Out)->@location(0) vec4f{
  let aa=style.b.z>0.0;
  var cover=1.0;
  if(aa){
    cover=clamp(i.edge.y+0.5-abs(i.edge.x),0.0,1.0)*clamp(0.5-i.edge.z,0.0,1.0)*clamp(0.5-i.edge.w,0.0,1.0);
  }
  let fw=max(fwidth(i.dist),1e-6);
  if((style.flags.z&32u)!=0u){
    let dash=style.a.z;let period=dash+style.a.w;
    let x=i.dist+style.b.x-dash*0.5+period*0.5;
    let t=x-period*floor(x/period)-period*0.5;
    let inside=dash*0.5-abs(t);
    cover*=select(select(0.0,1.0,inside>=0.0),clamp(inside/fw+0.5,0.0,1.0),aa);
  }


  let clipCount=style.flags.w&0xffffu;var clipBehind=0u;
  for(var p=0u;p<clipCount;p++){if(dot(style.planes[p].xyz,i.world)+style.planes[p].w<0.0){clipBehind++;}}
  if(clipCount>0u&&select(clipBehind>0u,clipBehind==clipCount,(style.flags.w&65536u)!=0u)){discard;}
  let alpha=i.color.a*cover;
  var rgb=max(i.color.rgb,vec3f(0.0));
  if(frame.extra.x>0.5){rgb=encode(min(rgb,vec3f(1.0)));}
  return vec4f(rgb,alpha);
}
`,fe=(e,t)=>t?e.replace(`let alpha=i.color.a*cover;`,`if(cover${t===1?`<`:`>=`}0.5){discard;}let alpha=i.color.a*cover;`):e,pe=e=>e.replace(`if((style.flags.z&32u)!=0u){
    let dash=`,`if(false){
    let dash=`)+`
@vertex fn fillVertex(@builtin(vertex_index) vi:u32)->Out{
  var o:Out;
  let p=points[vi];let w=style.model*vec4f(p.xyz,1.0);
  o.clip=frame.viewProj*w;
  o.color=vec4f(style.color.rgb,style.color.a*p.w);
  o.edge=vec4f(0.0,1.0,-1e4,-1e4);o.dist=0.0;o.world=w.xyz/w.w;
  return o;
}
`,me=e=>e.replace(`let rawA=halfWidth(ca);let rawB=halfWidth(cb);`,`let rawA=halfWidth(ca)*mix(points[ia].w,points[ib].w,ta);let rawB=halfWidth(cb)*mix(points[ia].w,points[ib].w,tb);`),he=e=>e.replace(`o.clip=vec4f(base.xy+cr.off/(0.5*frame.viewport.xy)*base.w,base.z,base.w);`,`o.clip=vec4f(base.xy+cr.off/(0.5*frame.viewport.xy)*base.w,min(base.z*(1.0+style.b.w),base.w),base.w);`).replace(`o.clip=placed;`,`o.clip=vec4f(placed.xy,min(placed.z*(1.0+style.b.w),placed.w),placed.w);`),ge=(e,t=!1)=>e+`
@vertex fn ribbonVertex(@builtin(vertex_index) vi:u32,@builtin(instance_index) ii:u32)->Out{
  var o:Out;
  o.clip=vec4f(2.0,2.0,0.0,1.0);o.color=vec4f(0.0);o.edge=vec4f(0.0,1.0,-1e4,-1e4);o.dist=0.0;
  if(vi>=6u){return o;}
  let ends=array<u32,6>(0u,0u,1u,0u,1u,1u);let sides=array<f32,6>(-1.0,1.0,1.0,-1.0,1.0,-1.0);
  let k=ii+ends[vi];let last=style.flags.y-1u;
  let before=style.model*vec4f(points[select(k,k-1u,k>0u)].xyz,1.0);
  let after=style.model*vec4f(points[min(k+1u,last)].xyz,1.0);
  let here=style.model*vec4f(points[k].xyz,1.0);
  let across=cross(vec3f(style.a.zw,style.b.x),after.xyz/after.w-before.xyz/before.w);
  let size=length(across);
  let side=select(vec3f(0.0),across/size,size>1e-9);
  let w=here.xyz/here.w+side*(sides[vi]*0.5*style.a.x*points[k].w);
  let placed=frame.viewProj*vec4f(w,1.0);
  o.clip=placed;
  var tint=vec4f(1.0);
  if((style.flags.z&64u)!=0u){tint=colors[k];}
  o.color=tinted(tint,style.flags.z,1.0);
  if(margoMaskPresent()){let on=margoMaskOn(ii)&&margoMaskOn(ii+1u);if(margoMaskHidden(on)){o.clip=vec4f(2.0,2.0,0.0,1.0);return o;}o.color=margoMaskColor(o.color,on);}
  o.world=w;${t?`o.segment=ii;`:``}
  return o;
}
`,_e=`cover*=select(select(0.0,1.0,inside>=0.0),clamp(inside/fw+0.5,0.0,1.0),aa);`,ve=(e,t)=>e.replace(_e,t===`square`?`let past=inside/fw+i.edge.y;cover*=select(select(0.0,1.0,past>=0.0),clamp(past+0.5,0.0,1.0),aa);`:`let past=max(-inside/fw,0.0);let sd=sqrt(past*past+i.edge.x*i.edge.x)-i.edge.y;cover=min(cover,select(select(0.0,1.0,sd<=0.0),clamp(0.5-sd,0.0,1.0),aa));`),ye=[[`var rgb=max(i.color.rgb,vec3f(0.0));`,`var rgb=max(i.color.rgb,vec3f(0.0));rgb=mix(rgb,margoFog.color.rgb,fogAmount(i.world));`]];function be(){let e=de;for(let[t,n]of ye){if(!e.includes(t))throw new i(`unsupported`,`Line fog needs the line shader it was written for; update the fog edits with it`);e=e.replace(t,n)}return e+ce(2,0)}var w=224,T=1,E=2,xe=4,Se=8,D=16,Ce=32,we=64,Te=128,Ee=256,O=512,k=1024,A=2048,De={binding:7,visibility:1,buffer:{type:`read-only-storage`,minBindingSize:16}},Oe=e=>e.fillOpaque&&e.material.opacity===1&&!e.material.behind,ke=7,Ae=class e{coreRequirement=t(`1.0.0`,import.meta.url);memoryFor(e){let t=this.resources.get(e);return t?{cpu:[t.floats,t.uints,t.written],gpu:[t.uniform,t.points,t.colors,...t.mask?[t.mask]:[],...t.fill?[t.fill.buffer]:[]]}:{cpu:[],gpu:[]}}static attach(r,i){n(r,t(`1.0.0`,import.meta.url));let a=new e(i);return r.use(a),a}constructor(e={}){if(this.stats={lines:0,segments:0,drawCalls:0},this.members=new Set,this.resources=new Map,this.watchers=new Set,this.pipelines=new Map,this.modules=new Map,this.extendedLayouts=new Map,this.elapsed=0,this.frameData=new Float32Array(24),this.frameBits=new Uint32Array(this.frameData.buffer),this.frameWritten=new Uint32Array(24),this.frameValid=!1,this.drawLists=[[],[],[],[]],this.fillLists=[[],[]],this.descriptor=c(),this.writeDescriptor=ee(),this.fogSource=null,this.fogData=new Float32Array(12),this.execute=e=>{let t=this.stats;if(t.lines=t.segments=t.drawCalls=0,e.backend!==`webgpu`||!this.device||!this.engine||e.device!==this.device)return;s.hook?.lines(this);let n=this.engine,r=this.device,i=this.drawLists;this.collect(n,0);for(let e of i)for(let[n]of e)t.lines++,t.segments+=n.segmentCount;if(!t.lines)return;let a=n.canvas,o=this.frameData,c=e.camera;ie(o,c.matrix,c,e.width,e.height,a.clientWidth?e.width/a.clientWidth:1,e.height,e.format.endsWith(`-srgb`)||e.format.includes(`float`)?0:1);let l=!this.frameValid;for(let e=0;!l&&e<this.frameBits.length;e++)l=this.frameBits[e]!==this.frameWritten[e];l&&(r.queue.writeBuffer(this.frameBuffer,0,o),this.frameWritten.set(this.frameBits),this.frameValid=!0);let u=this.fogSource,d=!1;if(u)for(let e of i)for(let[t]of e)d||=t.material.fog;d&&(ue(u,c.position,this.fogData),r.queue.writeBuffer(this.fogResources().buffer,0,this.fogData));let f=this.fillLists,p=i[0].length||i[2].length||f.some(e=>e.some(([e])=>Oe(e)))?this.writeDescriptor:this.descriptor;p.colorAttachments[0].view=e.color,p.depthStencilAttachment.view=e.depth;let m=e.encoder.beginRenderPass(p);se(m,e),m.setBindGroup(0,this.frameGroup),d&&m.setBindGroup(2,this.fogGpu.group);for(let t=0;t<4;t+=2){let n=t?T:0;this.drawFills(m,e,f[t/2],d,n),this.drawList(m,e,i[t],d,n|2052),this.drawList(m,e,i[t],d,n|2*A),this.drawList(m,e,i[t+1],d,n)}m.end();for(let e of i)e.length=0},this.name=e.name??`lines`,this.order=e.order??20,!this.name||typeof this.name!=`string`||!Number.isFinite(this.order))throw TypeError(`Invalid Lines options; pass the documented option types`)}get lines(){return this.members}get fog(){return this.fogSource}setFog(e){return this.fogSource=le(e),this}add(e){if(!(e instanceof x))throw TypeError(`Expected a Line`);e.bind(this),this.members.add(e);for(let t of this.watchers)t.added(e);return e}remove(e){if(this.members.delete(e)){for(let t of this.watchers)t.removed(e);this.release(e),e.bind(void 0)}}clear(){for(let e of[...this.members])this.remove(e)}get time(){return this.elapsed}resetTime(){this.elapsed=0;for(let e of this.members)e.resetTime?.()}advanceTime(e){if(e>0){this.elapsed+=e;for(let t of this.members)t.visible&&t.advanceTime?.(e)}}onPreUpdate(e){this.advanceTime(e)}setup(e){ae(e,`Lines`),this.engine=e;let t=this.device=e.gpu,n=(e,t)=>({binding:0,visibility:t,buffer:{type:`uniform`,minBindingSize:e}}),r=t.createBindGroupLayout({entries:[n(96,GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT)]}),i=t.createBindGroupLayout({entries:[n(w,GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT),{binding:1,visibility:GPUShaderStage.VERTEX,buffer:{type:`read-only-storage`,minBindingSize:16}},{binding:2,visibility:GPUShaderStage.VERTEX,buffer:{type:`read-only-storage`,minBindingSize:16}},De]});this.noMask=t.createBuffer({size:16,usage:GPUBufferUsage.STORAGE}),this.layouts={frame:r,style:i,pipeline:t.createPipelineLayout({bindGroupLayouts:[r,i]})},this.module(0),this.frameBuffer=t.createBuffer({size:96,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this.frameValid=!1,this.frameGroup=t.createBindGroup({layout:r,entries:[{binding:0,resource:{buffer:this.frameBuffer}}]})}registerPasses(e){e.add({name:`${this.name}:draw`,order:this.order,execute:this.execute})}module(e,t){let n=`${e&-86}|${t?.key??``}`,r=this.modules.get(n);if(!r){let i=e&E?be():de;e&k&&(i=ge(i)),e&Se&&(i=me(i)),e&Ce&&(i=he(i)),e&Te&&(i=ve(i,`round`)),e&Ee&&(i=ve(i,`square`)),e&O&&(i=pe(i)),i=fe(i,Math.floor(e/A)),t&&(i=t.shader(i)),s.hook&&(i=s.hook.shader(i)),r=this.device.createShaderModule({code:i}),this.modules.set(n,r)}return r}pipeline(e,t,n,r,i){let a=`${e}|${t}|${n}|${r}|${i?.key??``}`,o=this.pipelines.get(a);if(!o){let s=(r&E)!==0,c=(r&we)!==0,l=s?this.fogResources():void 0,u=this.module(r,i);o=this.device.createRenderPipeline({layout:i?this.device.createPipelineLayout({bindGroupLayouts:[this.layouts.frame,this.styleLayout(i),...l?[l.layout]:[]]}):l?.pipeline??this.layouts.pipeline,vertex:{module:u,entryPoint:r&O?`fillVertex`:r&k?`ribbonVertex`:`vertex`},fragment:{module:u,entryPoint:`fragment`,targets:[c?{format:e,writeMask:ke}:{format:e,blend:h}]},primitive:{topology:`triangle-list`,cullMode:`none`},multisample:c?{count:n,alphaToCoverageEnabled:!0}:{count:n},depthStencil:{format:t,depthWriteEnabled:(r&xe)!==0,depthCompare:r&T?`always`:r&D?`less`:`greater-equal`}}),this.pipelines.set(a,o)}return o}fogResources(){if(this.fogGpu)return this.fogGpu;let e=this.device,t=this.layouts,n=e.createBindGroupLayout({entries:[{binding:0,visibility:GPUShaderStage.FRAGMENT,buffer:{type:`uniform`,minBindingSize:48}}]}),r=e.createBuffer({size:48,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return this.fogGpu={layout:n,buffer:r,pipeline:e.createPipelineLayout({bindGroupLayouts:[t.frame,t.style,n]}),group:e.createBindGroup({layout:n,entries:[{binding:0,resource:{buffer:r}}]})}}ensure(e){let t=this.device,n=e.colors,r=this.resources.get(e);if(r&&r.capacity===e.capacityVersion)return r;r&&this.release(e);let i=[],a;try{let o=(e,n)=>{let r=t.createBuffer({size:e,usage:n});return i.push(r),r},s=o(w,GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST),c=e.points.length/4,l=Math.ceil(c/2)*4,u=o(Math.max(16,e.points.byteLength+l*4),GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),d=o(Math.max(16,n?.byteLength??16),GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST),f=e.mask?o(e.mask.byteLength,GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST):null;a=e.extension?.create(t);let p=t.createBindGroup({layout:this.styleLayout(e.extension),entries:[{binding:0,resource:{buffer:s}},{binding:1,resource:{buffer:u}},{binding:2,resource:{buffer:d}},{binding:7,resource:{buffer:f??this.noMask}},...a?.entries??[]]}),m=new ArrayBuffer(w);r={extra:a,uniform:s,points:u,colors:d,mask:f,maskVersion:-1,group:p,capacity:e.capacityVersion,version:-1,style:m,floats:new Float32Array(m),uints:new Uint32Array(m),written:new Float32Array(w/4).fill(NaN),near:new Float32Array(l),nearMode:``}}catch(e){a?.dispose();for(let e of i)e.destroy();throw e}return this.resources.set(e,r),r}styleLayout(e){if(!e)return this.layouts.style;let t=this.extendedLayouts.get(e.key);return t||(t=this.device.createBindGroupLayout({entries:[{binding:0,visibility:3,buffer:{type:`uniform`,minBindingSize:w}},{binding:1,visibility:1,buffer:{type:`read-only-storage`,minBindingSize:16}},{binding:2,visibility:1,buffer:{type:`read-only-storage`,minBindingSize:16}},De,...e.entries]}),this.extendedLayouts.set(e.key,t)),t}release(e){let t=this.resources.get(e);t&&(t.extra?.dispose(),t.uniform.destroy(),t.points.destroy(),t.colors.destroy(),t.mask?.destroy(),t.fill?.buffer.destroy(),this.resources.delete(e))}uploadFill(e,t,n){let r=this.device;if(t.fill?.bytes!==n.byteLength){t.fill?.buffer.destroy();let e=r.createBuffer({size:n.byteLength,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});t.fill={buffer:e,group:r.createBindGroup({layout:this.layouts.style,entries:[{binding:0,resource:{buffer:t.uniform}},{binding:1,resource:{buffer:e}},{binding:2,resource:{buffer:t.colors}},{binding:7,resource:{buffer:t.mask??this.noMask}}]}),bytes:n.byteLength,version:-1}}t.fill.version!==e.fillVersion&&(r.queue.writeBuffer(t.fill.buffer,0,n),t.fill.version=e.fillVersion)}collect(e,t){let n=this.device,r=this.drawLists;for(let e of r)e.length=0;for(let e of this.fillLists)e.length=0;for(let i of this.members){if(!i.visible||i.update(e,t)===!1)continue;let a=i.attachedMesh,o=a?S(e,a):i.matrix;if(!o)continue;let s=i.segmentCount,c=i.material;if(!s)continue;c.validate(),(c.dashed||i.extension)&&i.updateDistances(o);let l=this.ensure(i);if(l.extra?.update(),l.version!==i.version&&(n.queue.writeBuffer(l.points,0,i.points,0,i.count*4),l.nearMode=``,i.colors&&n.queue.writeBuffer(l.colors,0,i.colors,0,i.count*4),l.version=i.version),i.mode!==`segments`&&l.nearMode!==i.mode){let e=i.count,t=_(i.points,e,i.mode,l.near);n.queue.writeBuffer(l.points,e*16,t,0,Math.ceil(e/2)*4),l.nearMode=i.mode}l.mask&&i.mask&&l.maskVersion!==i.maskVersion&&(n.queue.writeBuffer(l.mask,0,i.mask),l.maskVersion=i.maskVersion);let u=l.floats,d=l.uints;u.set(o,0),u.set(c.color,16),u[19]=c.opacity,u[20]=c.width,u[21]=c.miterLimit,i.flatNormal?u.set(i.flatNormal,22):(u[22]=c.dashSize,u[23]=c.gapSize,u[24]=c.dashOffset),u[25]=i.totalDistance,u[26]=+!!c.antialias,u[27]=c.depthBias;let f=(c.vertexColors??!0)&&i.colors!==null;d[28]=b.indexOf(i.mode),d[29]=i.count,d[30]=m.indexOf(c.join)|ne.indexOf(c.cap)<<2|(c.worldUnits?16:0)|(c.dashed&&!i.flatNormal?32:0)|(f?64:0)|(f&&c.colorMode===`set`?128:0)|(f&&c.colorMode===`add`?256:0);let p=c.clipping;d[31]=p.length/4+(c.clipIntersection?65536:0),u.set(p,32),u.fill(0,32+p.length);let h=!1;for(let e=0;e<u.length;e++)if(!Object.is(l.written[e],u[e])){h=!0;break}h&&(n.queue.writeBuffer(l.uniform,0,l.style),l.written.set(u)),r[(c.onTop?2:0)+(c.depthWrite&&!c.behind?0:1)].push([i,l]);let g=i.fill;g?.length&&(this.uploadFill(i,l,g),this.fillLists[+!!c.onTop].push([i,l]))}}drawFills(e,t,n,r,i){let a=t.descriptor.depthStencil.format,o=t.descriptor.multisample?.count??1;for(let[s,c]of n){let{fog:n,behind:l}=s.material,u=(Oe(s)?xe:0)|(l?D:0)|(r&&n?E:0);e.setPipeline(this.pipeline(t.format,a,o,O|i|u)),e.setBindGroup(1,c.fill.group),e.draw(s.fill.length/4),this.stats.drawCalls++}}drawList(e,t,n,r,i){let a=t.descriptor.depthStencil.format,o=t.descriptor.multisample?.count??1,s=i>=2*A,c;for(let[l,u]of n){let{fog:n,antialias:d,dashed:f,dashCap:p,behind:m,depthBias:h,alphaToCoverage:g}=l.material,_=g&&o>1;if(s&&(!d||_))continue;let v=(l.pointWidths&&!f?Se:0)|(l.flatNormal?k:0)|(m?D:0)|(h?Ce:0)|(_?we:0)|(f&&p===`round`?Te:0)|(f&&p===`square`?Ee:0)|(r&&n?E:0),y=this.pipeline(t.format,a,o,(_?i%A:i)|v,l.extension);y!==c&&e.setPipeline(c=y),e.setBindGroup(1,u.group),e.draw(this.vertexCount(l),l.segmentCount),this.stats.drawCalls++}}vertexCount(e){return e.mode===`segments`&&e.material.cap!==`round`&&!e.extension?6:78}onDeviceRestored(e){this.releaseGpu(),this.setup(e)}releaseGpu(){for(let e of[...this.resources.keys()])this.release(e);this.extendedLayouts.clear(),this.frameBuffer?.destroy(),this.noMask?.destroy(),this.fogGpu?.buffer.destroy(),this.frameBuffer=this.frameGroup=this.layouts=this.device=this.fogGpu=this.noMask=void 0,this.pipelines.clear(),this.modules.clear()}dispose(){this.engine?.sceneOf?.(this)?.removePlugin(this.name),this.releaseGpu(),this.engine=void 0}[Symbol.dispose??Symbol()](){this.dispose()}},j=Symbol.for(`margoengine.mesh-sources.v1`),je=globalThis[j]??new WeakMap;globalThis[j]||Object.defineProperty(globalThis,j,{value:je});var M=Symbol.for(`margoengine.geometry-surfaces.v1`),Me=globalThis[M]??new WeakMap;globalThis[M]||Object.defineProperty(globalThis,M,{value:Me});function Ne(e){if(e?.geometry)return{kind:`core`,geometry:e.geometry};let t=e&&je.get(e);if(!t||t.model.disposed)return null;try{e.check?.()}catch{return null}return{kind:`pbr`,source:t}}var Pe=`#8f8f8f`,Fe=`#5e5e5e`,N=`#f0931e`,Ie=`#e8459a`,Le=[[`#f03c3c`,`#ff9c9c`],[`#2fbf3f`,`#9ee8a6`],[`#3a78f2`,`#a3c1ff`]],Re=`#f0a030`,ze=`#e0503c`,Be=`#33b8e8`,Ve=`#a0a0a0`,He=`#5cc45c`,P=.25,Ue=.5,F=12,We=.999;function Ge(e,t,{near:n,far:r}){let i=[],a=[],o=(r-n)/16,s=(e,t)=>{let i=Math.min(1,Math.max(0,(Math.hypot(e,t)-n)/(r-n)));return 1-i*i*(3-2*i)};for(let c=0;c<t.length;c++){let[l,u,d,f]=e.slice(c*4,c*4+4),p=d-l,m=f-u,h=p*p+m*m,g=2*(l*p+u*m),_=Math.sqrt(h),v=[0,1];for(let e of[n,r]){let t=g*g-4*h*(l*l+u*u-e*e);if(h>0&&t>0)for(let e of[(-g-Math.sqrt(t))/(2*h),(-g+Math.sqrt(t))/(2*h)])e>0&&e<1&&v.push(e)}v.sort((e,t)=>e-t);for(let e=1;e<v.length;e++){let d=v[e-1],f=v[e],h=Math.hypot(l+p*(d+f)*.5,u+m*(d+f)*.5);if(f<=d||h>=r)continue;let g=Math.max(h,Math.hypot(l+p*d,u+m*d),Math.hypot(l+p*f,u+m*f))<=n?1:Math.min(64,Math.max(1,Math.ceil(_*(f-d)/o)));for(let e=0;e<g;e++)for(let n of[d+(f-d)*e/g,d+(f-d)*(e+1)/g]){let e=l+p*n,r=u+m*n;i.push(e,0,r),a.push(t[c][0],t[c][1],t[c][2],s(e,r))}}}return[Float32Array.from(i),Float32Array.from(a)]}function Ke(e){if(e!==void 0&&!(typeof e==`object`&&e&&Number.isFinite(e.near)&&Number.isFinite(e.far)&&e.near>=0&&e.far>e.near))throw RangeError(`Invalid grid fade; pass { near, far } in world units with 0 <= near < far, both finite`)}var I=e=>({cap:`butt`,join:`miter`,...e}),L=e=>Array.from(o(e));function R(e,t){if(!e||typeof e.length!=`number`||e.length!==3)throw TypeError(`${t} needs 3 values; pass [x, y, z]`);return l(e,t),[e[0],e[1],e[2]]}function qe(e,t){let[n,r,i]=R(e,t),a=Math.hypot(n,r,i);if(!(a>0))throw RangeError(`${t} must be nonzero; pass a direction with a length`);return[n/a,r/a,i/a]}function Je(e){let t=Math.abs(e[1])>We,n=t?-e[1]:e[2],r=t?e[0]:0,i=t?0:-e[0],a=Math.hypot(n,r,i);return n/=a,r/=a,i/=a,[[n,r,i],[e[1]*i-e[2]*r,e[2]*n-e[0]*i,e[0]*r-e[1]*n]]}function Ye(e,t,n){let r=0,i=(i,a)=>{for(let o of[i,a])e[r++]=o&1?n[0]:t[0],e[r++]=o&2?n[1]:t[1],e[r++]=o&4?n[2]:t[2]};for(let e=0;e<8;e++)for(let t of[1,2,4])e&t||i(e,e|t)}var Xe=class extends x{constructor(e={}){let{size:t=10,divisions:n=10,color1:r=Pe,color2:i=Fe,fade:a,...o}=e;if(!(t>0)||!Number.isFinite(t)||!Number.isInteger(n)||n<1||n>1e4)throw RangeError(`Invalid grid size or divisions; pass a positive size and an integer divisions 1..10000`);Ke(a),super({...I(o),mode:`segments`});let s=L(r),c=L(i),l=t/2,u=n+1,d=new Float32Array(u*12),f=new Float32Array(u*12),p=0,m=0;for(let e=0;e<u;e++){let r=-l+e*t/n,i=n%2==0&&e*2===n?s:c;d.set([-l,0,r,l,0,r,r,0,-l,r,0,l],p),p+=12;for(let e=0;e<4;e++,m+=3)f.set(i,m)}if(!a){this.setPositions(d,f);return}let h=[],g=[];for(let e=0;e<d.length;e+=6)h.push(d[e],d[e+2],d[e+3],d[e+5]),g.push(Array.from(f.subarray(e,e+3)));this.setPositions(...Ge(h,g,a))}},Ze=class extends x{constructor(e={}){let{fade:t,radius:n=5,sectors:r=12,rings:i=5,divisions:a=72,color1:o=Pe,color2:s=Fe,...c}=e,l=e=>Number.isInteger(e)&&e>=0&&e<=4096;if(!(n>0)||!Number.isFinite(n)||!l(r)||!l(i)||!l(a)||a<3)throw RangeError(`Invalid polar grid options; pass a positive radius, sectors and rings 0..4096 and divisions 3..4096`);Ke(t),super({...I(c),mode:`segments`});let u=L(o),d=L(s),f=2*r+2*i*a,p=new Float32Array(f*3),m=new Float32Array(f*3),h=0,g=(e,t,n)=>{p[h]=e,p[h+2]=t,m.set(n,h),h+=3};for(let e=0;e<r;e++){let t=2*Math.PI*e/r,i=e%2?d:u;g(0,0,i),g(Math.sin(t)*n,Math.cos(t)*n,i)}for(let e=0;e<i;e++){let t=n*(i-e)/i,r=e%2?d:u;for(let e=0;e<a;e++){let n=2*Math.PI*e/a,i=2*Math.PI*(e+1)/a;g(Math.sin(n)*t,Math.cos(n)*t,r),g(Math.sin(i)*t,Math.cos(i)*t,r)}}if(!t){this.setPositions(p,m);return}let _=[],v=[];for(let e=0;e<p.length;e+=6)_.push(p[e],p[e+2],p[e+3],p[e+5]),v.push(Array.from(m.subarray(e,e+3)));this.setPositions(...Ge(_,v,t))}},Qe=class extends x{constructor(e={}){let{size:t=1,...n}=e;if(!(t>0)||!Number.isFinite(t))throw RangeError(`Axes size must be positive; pass a size above 0`);super({...I(n),mode:`segments`});let r=[];for(let[e,t]of Le)r.push(...L(e),...L(t));this.setPositions([0,0,0,t,0,0,0,0,0,0,t,0,0,0,0,0,0,t],r)}setColors(e,t,n){if(t===void 0||n===void 0)return super.setColors(e);let r=[];for(let i of[e,t,n]){let e=L(i);r.push(...e,...e)}return super.setColors(r)}},$e=class extends x{constructor(e=[-.5,-.5,-.5],t=[.5,.5,.5],n={}){let{color:r=N,...i}=n;super({...I(i),color:r,mode:`segments`}),this.corners=new Float32Array(72),this.setBox(e,t)}setBox(e,t){let n=R(e,`Box min`),r=R(t,`Box max`);if(n.some((e,t)=>e>r[t]))throw RangeError(`Box min exceeds max; pass min <= max on every axis`);return Ye(this.corners,n,r),this.setPositions(this.corners)}},z=new WeakMap;function B(e){let t=z.get(e);if(t)return t;t=new Float32Array([1/0,1/0,1/0,-1/0,-1/0,-1/0]);let n=e.vertices;for(let e=0;e+2<n.length;e+=6)for(let r=0;r<3;r++){let i=n[e+r];i<t[r]&&(t[r]=i),i>t[r+3]&&(t[r+3]=i)}return z.set(e,t),t}function et(e){let t=z.get(e);return t||z.set(e,t=Float32Array.from(e.bounds)),t}var V=e=>{for(let t=0;t<e.length;t++)if(!Number.isFinite(e[t]))return!1;return!0},tt=class extends x{constructor(e,t={}){e.check();let{color:n=N,...r}=t;super({...I(r),color:n,mode:`segments`}),this.seenMatrix=new Float32Array(16).fill(NaN),this.seenBounds=new Float32Array(6).fill(NaN),this.seenSource=null,this.lo=new Float32Array(3),this.hi=new Float32Array(3),this.corner=new Float32Array(3),this.out=new Float32Array(72),this.followed=e,this.setPositions(this.out)}setFromMesh(e){return e.check(),this.followed=e,this.seenSource=null,this}update(t){let n=S(t,this.followed);if(!n)return!1;let r=Ne(e(this.followed));if(!r)return!1;let[i,a]=r.kind===`core`?[r.geometry,B(r.geometry)]:[r.source,et(r.source)];if(!V(n)||!V(a))return!1;let o=i!==this.seenSource,s=p(this.seenMatrix,n),c=p(this.seenBounds,a);if(!o&&!s&&!c)return!0;this.seenSource=i;let{lo:l,hi:u,corner:d}=this;l.fill(1/0),u.fill(-1/0);for(let e=0;e<8;e++){re(d,0,n,a[e&1?3:0],a[e&2?4:1],a[e&4?5:2]);for(let e=0;e<3;e++)l[e]=Math.min(l[e],d[e]),u[e]=Math.max(u[e],d[e])}return Ye(this.out,l,u),this.setPositions(this.out),!0}},nt=class extends x{constructor(e={}){let{direction:t=[0,0,1],origin:n=[0,0,0],length:r=1,color:i=N,headLength:a,headWidth:o,solidHead:s=!1,...c}=e;super({...I(c),color:i,mode:`segments`}),this.length=1,this.headLength=P,this.headWidth=P*Ue,this.out=new Float32Array(150),this.cone=s?new Float32Array(288):null,this.direction=qe(t,`Direction`),this.origin=R(n,`Arrow origin`),this.setLength(r,a,o)}setDirection(e){return this.direction=qe(e,`Direction`),this.build()}setOrigin(e){return this.origin=R(e,`Arrow origin`),this.build()}setLength(e,t=e*P,n=t*Ue){let r=[e,t,n];if(!r.every(Number.isFinite)||r.some(e=>e<0)||e===0||t>e)throw RangeError(`Invalid arrow length; pass a positive length and head sizes of 0 or more with headLength <= length`);return this.length=e,this.headLength=t,this.headWidth=n,this.build()}build(){let e=this.direction,t=this.origin,n=this.out,[r,i]=Je(e),a=this.length-this.headLength,o=this.headWidth/2,s=[t[0]+e[0]*a,t[1]+e[1]*a,t[2]+e[2]*a],c=[t[0]+e[0]*this.length,t[1]+e[1]*this.length,t[2]+e[2]*this.length];n.set(t,0),n.set(s,3);let l=(e,t)=>{let a=2*Math.PI*e/F,c=Math.cos(a)*o,l=Math.sin(a)*o;for(let e=0;e<3;e++)n[t+e]=s[e]+r[e]*c+i[e]*l};for(let e=0;e<F;e++){let t=6+e*12;n.set(c,t),l(e,t+3),l(e,t+6),l(e+1,t+9)}let u=this.cone;if(u){let e=(e,t,n)=>{for(let r=0;r<3;r++)u[e+r]=t[n+r];u[e+3]=1};for(let t=0;t<F;t++){let r=6+t*12,i=t*24;e(i,c,0),e(i+4,n,r+6),e(i+8,n,r+9),e(i+12,s,0),e(i+16,n,r+9),e(i+20,n,r+6)}this.setFill(u,!0)}return this.setPositions(n)}},H=NaN,U=1,W=0,G=(()=>{let e=[],t=t=>{let n=[[-1,-1],[1,-1],[1,1],[-1,1]];for(let r=0;r<4;r++)e.push([...n[r],t,...n[(r+1)%4],t,0])};t(U),t(W);for(let[t,n]of[[-1,-1],[1,-1],[1,1],[-1,1]])e.push([t,n,U,t,n,W,0]),e.push([H,H,H,t,n,U,1]);e.push([0,1.15,U,0,1.75,U,2]),e.push([-.3,1.45,U,0,1.75,U,2]),e.push([.3,1.45,U,0,1.75,U,2]),e.push([0,0,U,0,0,W,3]);for(let t of[U,W])e.push([-.25,0,t,.25,0,t,4]),e.push([0,-.25,t,0,.25,t,4]);return e.push([H,H,H,0,0,U,4]),e})(),rt=class extends x{constructor(e,t={}){let{aspect:n,...r}=t;super({...I(r),mode:`segments`}),this.camera=e,this.seen=new Float32Array(16).fill(NaN),this.inverse=new Float64Array(16),this.out=new Float32Array(G.length*6),this.aspect=n;let i=[Re,ze,Be,Ve,He].map(L),a=[];for(let e of G)a.push(...i[e[6]],...i[e[6]]);this.setPositions(this.out,a)}update(e){let t=this.camera;t!==e.camera&&t.update(this.aspect??e.canvas.width/Math.max(1,e.canvas.height),!0);let n=t.matrix,i=!1;for(let e=0;e<16;e++)this.seen[e]!==n[e]&&(i=!0);if(!i||!r(n,this.inverse))return!0;this.seen.set(n);let a=this.inverse,o=this.out,s=t.position,c=0,l=(e,t,n)=>{if(Number.isNaN(e))o[c]=s[0],o[c+1]=s[1],o[c+2]=s[2];else{let r=a[3]*e+a[7]*t+a[11]*n+a[15]||1;o[c]=(a[0]*e+a[4]*t+a[8]*n+a[12])/r,o[c+1]=(a[1]*e+a[5]*t+a[9]*n+a[13])/r,o[c+2]=(a[2]*e+a[6]*t+a[10]*n+a[14])/r}c+=3};for(let e of G)l(e[0],e[1],e[2]),l(e[3],e[4],e[5]);return V(o)&&this.setPositions(o),!0}},it=class extends x{constructor(e={}){let{normal:t=[0,1,0],constant:n=0,size:r=1,color:i=N,fillOpacity:a=0,...o}=e;if(super({...I(o),color:i,mode:`segments`}),this.out=new Float32Array(36),!(a>=0&&a<=1))throw RangeError(`Fill opacity must be 0..1`);this.fillOpacity=a,this.square=a?new Float32Array(24):null,this.setPlane(t,n,r)}setPlane(e,t=0,n=1){let r=R(e,`Direction`),i=Math.hypot(r[0],r[1],r[2]);if(!(i>0))throw RangeError(`Direction must be nonzero; pass a plane normal with a length`);if(!Number.isFinite(t)||!(n>0)||!Number.isFinite(n))throw RangeError(`Invalid plane; pass a finite constant and a positive size`);let a=r.map(e=>e/i),o=-t/i,s=a.map(e=>e*o),[c,l]=Je(a),u=n/2,d=(e,t)=>[0,1,2].map(n=>s[n]+(c[n]*e+l[n]*t)*u),f=[d(-1,-1),d(1,-1),d(1,1),d(-1,1)],p=0;for(let[e,t]of[[0,1],[1,2],[2,3],[3,0],[0,2],[1,3]])this.out.set(f[e],p),this.out.set(f[t],p+3),p+=6;let m=this.square;return m&&([0,1,2,0,2,3].forEach((e,t)=>{m.set(f[e],t*4),m[t*4+3]=this.fillOpacity}),this.setFill(m,this.fillOpacity===1)),this.setPositions(this.out)}};function at(e){return e.kind===`core`?{arrays:[e.geometry.vertices],stride:6,normal:3}:{arrays:e.source.primitives.map(e=>e.vertices),stride:20,normal:4}}var ot=class extends x{constructor(e,t={}){e.check();let{size:n=1,color:r=Ie,...i}=t;super({...I(i),color:r,mode:`segments`}),this.mesh=e,this.seenMatrix=new Float32Array(16).fill(NaN),this.seenSource=null,this.seenSize=NaN,this.valid=!1,this.out=new Float32Array(6),this.size=n,this.setPositions(this.out)}update(t){if(!Number.isFinite(this.size))throw RangeError(`VertexNormalsHelper size must be finite; set size to a length in world units`);let n=S(t,this.mesh);if(!n)return!1;let r=Ne(e(this.mesh));if(!r||!V(n))return!1;let i=r.kind===`core`?r.geometry:r.source;if(!p(this.seenMatrix,n)&&i===this.seenSource&&this.size===this.seenSize)return this.valid;this.seenSource=i,this.seenSize=this.size;let a=[n[0],n[1],n[2]],o=[n[4],n[5],n[6]],s=[n[8],n[9],n[10]],c=(e,t)=>[e[1]*t[2]-e[2]*t[1],e[2]*t[0]-e[0]*t[2],e[0]*t[1]-e[1]*t[0]],l=c(o,s),u=c(s,a),d=c(a,o),f=a[0]*l[0]+a[1]*l[1]+a[2]*l[2];if(!f||!Number.isFinite(f))return this.valid=!1;let{arrays:m,stride:h,normal:g}=at(r),_=0;for(let e of m)_+=Math.floor(e.length/h);if(!_)return this.valid=!1;this.out.length!==_*6&&(this.out=new Float32Array(_*6));let v=this.out,y=f<0?-1:1,b=0;for(let e of m)for(let t=0;t+h<=e.length;t+=h){re(v,b,n,e[t],e[t+1],e[t+2]);let r=e[t+g],i=e[t+g+1],a=e[t+g+2],o=(l[0]*r+u[0]*i+d[0]*a)*y,s=(l[1]*r+u[1]*i+d[1]*a)*y,c=(l[2]*r+u[2]*i+d[2]*a)*y,f=Math.hypot(o,s,c),p=f>0?this.size/f:0;o*=p,s*=p,c*=p,v[b+3]=v[b]+o,v[b+4]=v[b+1]+s,v[b+5]=v[b+2]+c,b+=6}return V(v)?(this.setPositions(v),this.valid=!0):this.valid=!1}},K=e=>Array.isArray(e)&&e.length===3&&e.every(Number.isFinite);function q(e){if(!e||typeof e!=`object`)return null;let t=e;return`sky`in t?`hemisphere`:K(t.position)&&K(t.direction)&&typeof t.width==`number`&&typeof t.height==`number`?`rect`:K(t.position)?K(t.direction)?`spot`:`point`:K(t.direction)?`directional`:null}var J=e=>{let t=Math.hypot(e[0],e[1],e[2])||1;return[e[0]/t,e[1]/t,e[2]/t]},Y=(e,t)=>[e[1]*t[2]-e[2]*t[1],e[2]*t[0]-e[0]*t[2],e[0]*t[1]-e[1]*t[0]];function st(e){let t=J(Y(Math.abs(e[1])<.99?[0,1,0]:[1,0,0],e));return[t,Y(e,t)]}function X(e){let t=e?[e[0],e[1],e[2]].map(e=>Math.max(0,e)):[1,1,1],n=Math.max(...t);return n>0?t.map(e=>e/n):[1,1,1]}var ct=class{constructor(){this.positions=[],this.colors=[],this.color=[1,1,1]}clear(){this.positions.length=this.colors.length=0}line(e,t,n=this.color){this.positions.push(e[0],e[1],e[2],t[0],t[1],t[2]),this.colors.push(n[0],n[1],n[2],n[0],n[1],n[2])}circle(e,t,n,r,i){let a=this.circleData;if(!a){let e=new Float64Array(66);for(let t=0;t<=32;t++){let n=t/32*Math.PI*2;e[t*2]=Math.cos(n),e[t*2+1]=Math.sin(n)}this.circleData=a={trig:e,p:[0,0,0],q:[0,0,0]}}let{trig:o,p:s,q:c}=a;for(let a=0;a<32;a++){for(let i=0;i<3;i++)s[i]=e[i]+(t[i]*o[a*2]+n[i]*o[a*2+1])*r,c[i]=e[i]+(t[i]*o[(a+1)*2]+n[i]*o[(a+1)*2+1])*r;this.line(s,c,i?i((s[1]+c[1])/2-e[1]):this.color)}}};function lt(e,t,n,r){let i=q(t),a=n.size??.25,s=n.position??[0,0,0];if(!i)return;if(e.color=r??X(t.color),i===`hemisphere`){let n=t,i=r??X(o(n.sky)),c=r??X(o(n.ground??n.sky)),l=e=>e>=0?i:c;e.circle(s,[1,0,0],[0,1,0],a,l),e.circle(s,[0,0,1],[0,1,0],a,l),e.circle(s,[1,0,0],[0,0,1],a,()=>c),e.line(s,[s[0],s[1]+a*1.5,s[2]],i);return}if(i===`directional`){let n=J(t.direction),[r,i]=st(n),o=(e,t)=>[0,1,2].map(n=>s[n]+(r[n]*e+i[n]*t)*(a/2)),c=[o(-1,-1),o(1,-1),o(1,1),o(-1,1)];for(let t=0;t<4;t++)e.line(c[t],c[(t+1)%4]);e.line(s,[0,1,2].map(e=>s[e]+n[e]*a*2));return}let c=t.position;if(i===`point`){e.circle(c,[1,0,0],[0,1,0],a),e.circle(c,[0,0,1],[0,1,0],a),e.circle(c,[1,0,0],[0,0,1],a);return}if(i===`rect`){let n=t,r=J(n.direction),i=n.up??(Math.abs(r[1])>.999?[0,0,1]:[0,1,0]),a=J(Y([i[0],i[1],i[2]],r)),o=Y(r,a),s=(e,t)=>[0,1,2].map(r=>c[r]+(a[r]*e*n.width+o[r]*t*n.height)/2),l=[s(-1,-1),s(1,-1),s(1,1),s(-1,1)];for(let t=0;t<4;t++)e.line(l[t],l[(t+1)%4]);e.line(c,[0,1,2].map(e=>c[e]+r[e]*Math.min(n.width,n.height)/2));return}let l=t,u=J(l.direction),[d,f]=st(u),p=Math.min(l.angle??l.outerAngle??Math.PI/4,85*Math.PI/180),m=l.angle===void 0?l.innerAngle??0:l.angle*(1-(l.penumbra??0)),h=l.range&&l.range>0&&Number.isFinite(l.range)?l.range:n.length??1,g=[0,1,2].map(e=>c[e]+u[e]*h),_=h*Math.tan(p);for(let t=0;t<8;t++){let n=t/8*Math.PI*2;e.line(c,[0,1,2].map(e=>g[e]+(d[e]*Math.cos(n)+f[e]*Math.sin(n))*_))}e.circle(g,d,f,_),m>0&&m<p&&e.circle(g,d,f,h*Math.tan(m))}function ut(e,t){e.length=0;for(let n of t){let t=q(n);if(e.push(t?t.length:0),!t)continue;let r=n;for(let t of[`position`,`direction`,`color`,`up`]){let n=r[t];n?e.push(n[0],n[1],n[2]):e.push(NaN)}for(let t of[`range`,`outerAngle`,`innerAngle`,`angle`,`penumbra`,`width`,`height`])e.push(r[t]??NaN);t===`hemisphere`&&e.push(...o(r.sky),...o(r.ground??`#000`),+(r.ground===void 0))}return e.length}var dt=class extends x{constructor(e,t={}){if(typeof e!=`function`)throw TypeError(`LightsHelper takes a function returning the lights to draw; pass () => lights`);let{color:n,size:r,length:i,position:a,...s}=t;if(r!==void 0&&!(r>0)||i!==void 0&&!(i>0))throw RangeError(`Light helper size and length must be above 0`);if(a!==void 0&&!K(a))throw TypeError(`Light helper position needs 3 finite values`);super({cap:`butt`,join:`miter`,...s,mode:`segments`}),this.lights=e,this.options=t,this.segments=new ct,this.seen=[],this.next=[],this.fixed=n===void 0?null:o(n),this.update()}update(){let e=this.lights(),t=this.next;ut(t,e);let n=t.length===this.seen.length;for(let e=0;n&&e<t.length;e++)n=Object.is(t[e],this.seen[e]);if(n)return!0;this.seen.length=0,this.seen.push(...t);let r=this.segments;r.clear();for(let t of e)lt(r,t,this.options,this.fixed);return r.positions.length||r.line([0,0,0],[0,0,0]),this.setPositions(r.positions,r.colors),!0}},Z=class extends dt{constructor(e,t,n){let r=[e];if(super(()=>r,t),this.light=e,q(e)!==n)throw TypeError(`Expected a ${n} light`)}},ft=class extends Z{constructor(e,t={}){super(e,t,`point`)}},pt=class extends Z{constructor(e,t={}){super(e,t,`spot`)}},mt=class extends Z{constructor(e,t={}){super(e,t,`directional`)}},ht=class extends Z{constructor(e,t={}){super(e,t,`hemisphere`)}},gt=class extends Z{constructor(e,t={}){super(e,t,`rect`)}},Q=e=>`joints`in e,$=`SkeletonHelper`,_t=class e extends x{constructor(e,t={}){let n=e?.parents;if(!e||typeof e!=`object`||!Array.isArray(n)||!n.length)throw TypeError(`${$} needs a skeleton with parents; pass an animation Skeleton or {joints, parents}`);let r=n.length;if(n.forEach((e,t)=>{if(!Number.isInteger(e)||e<-1||e>=r||e===t)throw RangeError(`${$} bone ${t} parent ${e} is not another bone; use -1 or an index below ${r}`)}),Q(e)){if(!Array.isArray(e.joints)||e.joints.length!==r)throw TypeError(`${$} needs one joint mesh per parent entry; pass ${r} joints`);for(let t of e.joints)if(!t||typeof t.check!=`function`)throw TypeError(`${$} joints must be Margo Engine meshes; pass model.nodes entries`)}else if(!e.matrices||typeof e.matrices.length!=`number`)throw TypeError(`${$} skeleton needs matrices, 16 numbers per bone; pass an animation Skeleton`);let{color:i=`#ff7a2e`,parentColor:a=`#16b3a3`,mesh:o=null,matrix:s,...c}=t,l=Q(e);super({cap:`butt`,join:`miter`,onTop:!0,fog:!1,...c,mode:`segments`,mesh:l?null:o,matrix:l?void 0:s}),this.pairs=[],this.revisionSeen=NaN,this.valid=!1,this.skeleton=e;for(let e=0;e<r;e++)n[e]>=0&&this.pairs.push(n[e],e);if(l)for(let t of e.joints)t.check();this.seen=new Float64Array(r*3).fill(NaN),this.out=new Float32Array(Math.max(2,this.pairs.length)*3),this.setPositions(this.out),this.setColors(i,a)}static fromGLTF(t,n=0,r){let i=t?.asset?.doc,a=i?.skins?.[n]?.joints;if(!Array.isArray(a)||!Array.isArray(t.nodes))throw TypeError(`${$}.fromGLTF: the model has no skin ${n}; pass a gltf/pbr model and one of its skins`);let o=new Map;return(i.nodes??[]).forEach((e,t)=>e?.children?.forEach(e=>o.set(e,t))),new e({joints:a.map(e=>t.nodes[e]),parents:a.map(e=>a.indexOf(o.get(e)??-1))},r)}setColors(e,t){if(t===void 0)return super.setColors(e);let n=o(e),r=o(t),i=[];for(let e=0;e<this.count;e+=2)i.push(...r,...n);return super.setColors(i)}update(e){let t=this.skeleton,n=t.parents.length,r=this.seen,i=!1,a=(e,t,n,a)=>{(r[e*3]!==t||r[e*3+1]!==n||r[e*3+2]!==a)&&(r[e*3]=t,r[e*3+1]=n,r[e*3+2]=a,i=!0)};if(Q(t))for(let r=0;r<n;r++){let n=S(e,t.joints[r]);if(!n)return!1;a(r,n[12],n[13],n[14])}else{let e=t.revision;if(e!==void 0&&e===this.revisionSeen&&this.valid)return!0;let r=t.matrices;if(r.length<n*16)throw RangeError(`${$} skeleton has ${r.length} matrix numbers for ${n} bones; pass 16 per bone`);for(let e=0;e<n;e++)a(e,r[e*16+12],r[e*16+13],r[e*16+14]);this.revisionSeen=e??NaN}if(!i)return this.valid;let o=this.pairs,s=this.out;for(let e=0;e<o.length;e++)for(let t=0;t<3;t++)s[e*3+t]=r[o[e]*3+t];return s.every(Number.isFinite)?(this.setPositions(s),this.valid=!0):this.valid=!1}};export{nt as ArrowHelper,Qe as AxesHelper,$e as Box3Helper,tt as BoxHelper,rt as CameraHelper,mt as DirectionalLightHelper,Xe as GridHelper,ht as HemisphereLightHelper,dt as LightsHelper,x as Line,v as LineMaterial,Ae as Lines,it as PlaneHelper,ft as PointLightHelper,Ze as PolarGridHelper,gt as RectAreaLightHelper,_t as SkeletonHelper,pt as SpotLightHelper,g as VERTICES_PER_SEGMENT,ot as VertexNormalsHelper,te as computeLineDistances,_ as distinctNeighbours,u as expandLine,B as geometryBounds,q as lightKind,o as parseColor,y as segmentCount,d as segmentIndices,f as triangleArea};